package com.debtbook.debt_book

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity مطلوبة لعمل البصمة (local_auth)
class MainActivity : FlutterFragmentActivity()
