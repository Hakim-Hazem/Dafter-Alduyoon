# flutter_local_notifications (يستخدم Gson لحفظ التذكيرات المجدولة)
-keep class com.dexterous.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken

# Flutter deferred components (غير مستخدمة) — تجنب أخطاء R8
-dontwarn com.google.android.play.core.**
