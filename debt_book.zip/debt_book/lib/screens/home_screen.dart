import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/person.dart';
import '../models/person_summary.dart';
import '../utils/format.dart';
import '../utils/notifications_helper.dart';
import '../utils/pdf_helper.dart';
import '../utils/settings.dart';
import 'add_person_screen.dart';
import 'person_screen.dart';
import 'search_screen.dart';
import 'settings_screen.dart';
import 'statistics_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<PersonSummary>> _future;
  bool _hide = Settings.hideAmounts;
  int _tab = 0;
  int _statsVersion = 0;

  @override
  void initState() {
    super.initState();
    _future = DatabaseHelper.instance.getPersonSummaries();
    NotificationsHelper.rescheduleAll().catchError((_) {});
  }

  void _load() {
    setState(() => _future = DatabaseHelper.instance.getPersonSummaries());
  }

  String _amt(double v) => _hide ? '••••' : money(v);

  Future<void> _addPerson() async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => const AddPersonScreen()));
    _load();
  }

  Future<void> _openPerson(Person p) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => PersonScreen(person: p)));
    _load();
  }

  Future<void> _deletePerson(Person p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف شخص'),
        content: Text('هل تريد حذف "${p.name}" وكل ديونه؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true && p.id != null) {
      await DatabaseHelper.instance.deletePerson(p.id!);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHome(),
      StatisticsScreen(key: ValueKey(_statsVersion)),
      const SettingsScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _tab == 0 ? 'دفتر الديون' : (_tab == 1 ? 'الإحصائيات' : 'الإعدادات'),
        ),
        actions: [
          if (_tab == 0) ...[
            IconButton(
              tooltip: 'بحث',
              icon: const Icon(Icons.search),
              onPressed: () async {
                await Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SearchScreen()));
                _load();
              },
            ),
            IconButton(
              tooltip: _hide ? 'إظهار' : 'إخفاء',
              icon: Icon(_hide ? Icons.visibility_off : Icons.visibility),
              onPressed: () async {
                setState(() => _hide = !_hide);
                await Settings.setHideAmounts(_hide);
              },
            ),
            IconButton(
              tooltip: 'تقرير PDF',
              icon: const Icon(Icons.picture_as_pdf),
              onPressed: () => PdfHelper.exportFullReport(),
            ),
          ],
        ],
      ),
      body: IndexedStack(index: _tab, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) {
          setState(() {
            _tab = i;
            if (i == 1) _statsVersion++; // تحديث الإحصائيات عند فتحها
          });
          if (i == 0) _load();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'الإحصائيات'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
      floatingActionButton: _tab == 0
          ? FloatingActionButton.extended(
              onPressed: _addPerson,
              icon: const Icon(Icons.person_add),
              label: const Text('شخص جديد'),
            )
          : null,
    );
  }

  Widget _buildHome() {
    return FutureBuilder<List<PersonSummary>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final list = snap.data ?? [];
        double lent = 0, borrowed = 0;
        for (final s in list) {
          lent += s.lentRemaining;
          borrowed += s.borrowedRemaining;
        }
        return RefreshIndicator(
          onRefresh: () async => _load(),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              _totals(lent, borrowed),
              const SizedBox(height: 20),
              const Text('الأشخاص',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (list.isEmpty) _empty(),
              ...list.map(_personTile),
            ],
          ),
        );
      },
    );
  }

  Widget _totals(double lent, double borrowed) {
    final net = lent - borrowed;
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _box('لي (أقرضت)', lent, Colors.green)),
            const SizedBox(width: 12),
            Expanded(child: _box('عليّ (استدنت)', borrowed, Colors.red)),
          ],
        ),
        const SizedBox(height: 12),
        _box('الصافي', net, net >= 0 ? Colors.teal : Colors.orange, full: true),
      ],
    );
  }

  Widget _box(String title, double v, Color color, {bool full = false}) {
    return Container(
      width: full ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: TextStyle(color: color, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(_amt(v),
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.bold, color: color)),
        ],
      ),
    );
  }

  Widget _empty() {
    return Container(
      padding: const EdgeInsets.all(24),
      alignment: Alignment.center,
      child: const Text(
        'لا يوجد أشخاص بعد.\nأضف شخصاً للبدء بتسجيل الديون.',
        textAlign: TextAlign.center,
        style: TextStyle(color: Colors.grey),
      ),
    );
  }

  Widget _personTile(PersonSummary s) {
    final net = s.net;
    final color =
        net == 0 ? Colors.grey : (net > 0 ? Colors.green : Colors.red);
    final label = net == 0
        ? 'مسدد'
        : (net > 0 ? 'لي ${_amt(net)}' : 'عليّ ${_amt(net.abs())}');

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        onTap: () => _openPerson(s.person),
        onLongPress: () => _deletePerson(s.person),
        leading: CircleAvatar(
          child: Text(s.person.name.isNotEmpty ? s.person.name[0] : '?'),
        ),
        title: Text(s.person.name),
        subtitle: Text(label, style: TextStyle(color: color)),
        trailing: const Icon(Icons.chevron_left),
      ),
    );
  }
}
