import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../utils/format.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  late Future<Map<String, dynamic>> _future;

  @override
  void initState() {
    super.initState();
    _future = DatabaseHelper.instance.getStatistics();
  }

  void _load() {
    setState(() => _future = DatabaseHelper.instance.getStatistics());
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: _future,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        final s = snap.data ?? {};
        final lent = (s['lentRemaining'] as double?) ?? 0;
        final borrowed = (s['borrowedRemaining'] as double?) ?? 0;
        final monthly = (s['monthly'] as List?) ?? [];
        final categories = (s['categories'] as List?) ?? [];

        return RefreshIndicator(
          onRefresh: () async => _load(),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                children: [
                  Expanded(child: _statBox('لي', lent, Colors.green)),
                  const SizedBox(width: 12),
                  Expanded(child: _statBox('عليّ', borrowed, Colors.red)),
                ],
              ),
              const SizedBox(height: 20),
              _card(
                'الديون حسب التصنيف',
                SizedBox(
                  height: 220,
                  child: categories.isEmpty
                      ? const Center(child: Text('لا توجد بيانات'))
                      : PieChart(
                          PieChartData(
                            sections: categories.asMap().entries.map((e) {
                              final colors = [
                                Colors.green,
                                Colors.red,
                                Colors.blue,
                                Colors.orange,
                                Colors.purple,
                                Colors.teal,
                              ];
                              final total = categories.fold<double>(
                                  0,
                                  (a, b) =>
                                      a +
                                      ((b['total'] as num?) ?? 0).toDouble());
                              final val =
                                  ((e.value['total'] as num?) ?? 0).toDouble();
                              return PieChartSectionData(
                                value: val,
                                title: total == 0
                                    ? ''
                                    : '${((val / total) * 100).toStringAsFixed(0)}%',
                                color: colors[e.key % colors.length],
                                radius: 70,
                              );
                            }).toList(),
                            sectionsSpace: 2,
                            centerSpaceRadius: 30,
                          ),
                        ),
                ),
                legend: categories.asMap().entries.map((e) {
                  final colors = [
                    Colors.green,
                    Colors.red,
                    Colors.blue,
                    Colors.orange,
                    Colors.purple,
                    Colors.teal,
                  ];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          color: colors[e.key % colors.length],
                        ),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            '${e.value['cat']} — ${money(((e.value['total'] as num?) ?? 0).toDouble())}',
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              _card(
                'الديون الشهرية',
                SizedBox(
                  height: 220,
                  child: monthly.isEmpty
                      ? const Center(child: Text('لا توجد بيانات'))
                      : BarChart(
                          BarChartData(
                            alignment: BarChartAlignment.spaceAround,
                            titlesData: FlTitlesData(
                              leftTitles: const AxisTitles(
                                  sideTitles:
                                      SideTitles(showTitles: false)),
                              rightTitles: const AxisTitles(
                                  sideTitles:
                                      SideTitles(showTitles: false)),
                              topTitles: const AxisTitles(
                                  sideTitles:
                                      SideTitles(showTitles: false)),
                              bottomTitles: AxisTitles(
                                sideTitles: SideTitles(
                                  showTitles: true,
                                  getTitlesWidget: (v, m) {
                                    final idx = v.toInt();
                                    if (idx < 0 || idx >= monthly.length) {
                                      return const SizedBox();
                                    }
                                    final key =
                                        (monthly[idx]['m'] as String?) ?? '';
                                    return Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(monthLabel(key),
                                          style:
                                              const TextStyle(fontSize: 9)),
                                    );
                                  },
                                ),
                              ),
                            ),
                            borderData: FlBorderData(show: false),
                            barGroups: monthly
                                .asMap()
                                .entries
                                .map((e) {
                              final val = ((e.value['total'] as num?) ?? 0)
                                  .toDouble();
                              final type =
                                  (e.value['type'] as int?) ?? 0;
                              return BarChartGroupData(x: e.key, barRods: [
                                BarChartRodData(
                                  toY: val,
                                  color: type == 0
                                      ? Colors.green
                                      : Colors.red,
                                  width: 12,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ]);
                            }).toList(),
                          ),
                        ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _statBox(String t, double v, Color c) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: c.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: c.withOpacity(0.4)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(t, style: TextStyle(color: c, fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Text(money(v),
                style: TextStyle(
                    color: c, fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Widget _card(String title, Widget child, {List<Widget>? legend}) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            child,
            if (legend != null) ...[
              const SizedBox(height: 10),
              ...legend,
            ],
          ],
        ),
      ),
    );
  }
}
