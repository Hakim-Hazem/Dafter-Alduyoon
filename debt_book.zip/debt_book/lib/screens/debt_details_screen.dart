import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/debt.dart';
import '../models/payment.dart';
import '../utils/format.dart';
import '../utils/notifications_helper.dart';
import '../utils/pdf_helper.dart';
import 'add_debt_screen.dart';

class DebtDetailsScreen extends StatefulWidget {
  final Debt debt;
  const DebtDetailsScreen({super.key, required this.debt});

  @override
  State<DebtDetailsScreen> createState() => _DebtDetailsScreenState();
}

class _DebtDetailsScreenState extends State<DebtDetailsScreen> {
  late Future<List<Payment>> _future;
  String _personName = '';

  @override
  void initState() {
    super.initState();
    _future = DatabaseHelper.instance.getPayments(widget.debt.id!);
    _loadName();
  }

  Future<void> _loadName() async {
    final persons = await DatabaseHelper.instance.getAllPersons();
    final p = persons.where((p) => p.id == widget.debt.personId).toList();
    if (p.isNotEmpty && mounted) {
      setState(() => _personName = p.first.name);
    }
  }

  void _load() {
    setState(() =>
        _future = DatabaseHelper.instance.getPayments(widget.debt.id!));
  }

  Future<void> _editDebt() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AddDebtScreen(
          personId: widget.debt.personId,
          personName: _personName,
          existing: widget.debt,
        ),
      ),
    );
    if (mounted) Navigator.pop(context);
  }

  Future<void> _addPayment() async {
    final amountCtrl = TextEditingController();
    DateTime date = DateTime.now();

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('دفعة جديدة'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: amountCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'المبلغ',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                      child: Text('التاريخ: ${dateStr(date.toIso8601String())}')),
                  TextButton(
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: ctx,
                        initialDate: date,
                        firstDate: DateTime(2000),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) setD(() => date = picked);
                    },
                    child: const Text('تغيير'),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('إلغاء')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('حفظ')),
          ],
        ),
      ),
    );

    if (ok != true) return;
    final amount =
        double.tryParse(amountCtrl.text.trim().replaceAll(',', '.'));
    if (amount == null || amount <= 0) return;

    await DatabaseHelper.instance.insertPayment(Payment(
      debtId: widget.debt.id!,
      amount: amount,
      date: date.toIso8601String().substring(0, 10),
    ));
    _load();
  }

  Future<void> _deletePayment(Payment p) async {
    if (p.id == null) return;
    await DatabaseHelper.instance.deletePayment(p.id!);
    _load();
  }

  Future<void> _deleteDebt() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('حذف الدين'),
        content: const Text('هل تريد حذف هذا الدين وكل دفعاته؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('إلغاء')),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await DatabaseHelper.instance.deleteDebt(widget.debt.id!);
      await NotificationsHelper.cancel(widget.debt.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  Future<void> _exportReceipt(List<Payment> payments) async {
    await PdfHelper.exportDebtReceipt(
        widget.debt, payments, _personName);
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.debt;
    final isLent = d.type == 0;
    final color = isLent ? Colors.green : Colors.red;

    return Scaffold(
      appBar: AppBar(
        title: const Text('تفاصيل الدين'),
        actions: [
          IconButton(
            tooltip: 'تعديل',
            icon: const Icon(Icons.edit),
            onPressed: _editDebt,
          ),
          IconButton(
            tooltip: 'حذف',
            icon: const Icon(Icons.delete_outline),
            onPressed: _deleteDebt,
          ),
        ],
      ),
      body: FutureBuilder<List<Payment>>(
        future: _future,
        builder: (context, snap) {
          final payments = snap.data ?? [];
          double paid = 0;
          for (final p in payments) {
            paid += p.amount;
          }
          final remaining = d.amount - paid;

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: color.withOpacity(0.4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(isLent ? 'لي (أقرضت)' : 'عليّ (استدنت)',
                            style: TextStyle(
                                color: color, fontWeight: FontWeight.bold)),
                        const Spacer(),
                        if (d.category != null && d.category!.isNotEmpty)
                          Chip(
                            label: Text(d.category!,
                                style: const TextStyle(fontSize: 11)),
                            visualDensity: VisualDensity.compact,
                          ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('المبلغ: ${money(d.amount)} ${d.currency}',
                        style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 4),
                    Text('المسدد: ${money(paid)} ${d.currency}'),
                    const SizedBox(height: 4),
                    Text('المتبقي: ${money(remaining)} ${d.currency}',
                        style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                    const SizedBox(height: 8),
                    Text('تاريخ الدين: ${dateStr(d.date)}',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.grey)),
                    if (d.dueDate != null && d.dueDate!.isNotEmpty)
                      Text('الاستحقاق: ${dateStr(d.dueDate!)}',
                          style: const TextStyle(
                              fontSize: 12, color: Colors.grey)),
                    if (d.note != null && d.note!.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text('ملاحظة: ${d.note!}'),
                    ],
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => _exportReceipt(payments),
                      icon: const Icon(Icons.picture_as_pdf, size: 18),
                      label: const Text('تصدير إيصال PDF'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text('الدفعات',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (payments.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text('لا توجد دفعات بعد',
                      style: TextStyle(color: Colors.grey)),
                ),
              ...payments.map((p) => Card(
                    margin: const EdgeInsets.symmetric(vertical: 3),
                    child: ListTile(
                      leading: const Icon(Icons.check_circle,
                          color: Colors.green),
                      title: Text('${money(p.amount)} ${d.currency}'),
                      subtitle: Text(dateStr(p.date)),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _deletePayment(p),
                      ),
                    ),
                  )),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addPayment,
        icon: const Icon(Icons.add_card),
        label: const Text('إضافة دفعة'),
      ),
    );
  }
}
