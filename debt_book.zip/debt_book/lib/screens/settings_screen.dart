import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';

import '../utils/backup_helper.dart';
import '../utils/notifications_helper.dart';
import '../utils/pdf_helper.dart';
import '../utils/settings.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _section('المظهر'),
        Card(
          child: ListTile(
            leading: const Icon(Icons.dark_mode),
            title: const Text('الوضع الليلي'),
            subtitle: Text(
              Settings.themeMode.value == ThemeMode.dark
                  ? 'مفعّل'
                  : Settings.themeMode.value == ThemeMode.light
                      ? 'معطّل'
                      : 'حسب النظام',
            ),
            trailing: DropdownButton<ThemeMode>(
              value: Settings.themeMode.value,
              items: const [
                DropdownMenuItem(
                    value: ThemeMode.system, child: Text('النظام')),
                DropdownMenuItem(
                    value: ThemeMode.light, child: Text('نهاري')),
                DropdownMenuItem(
                    value: ThemeMode.dark, child: Text('ليلي')),
              ],
              onChanged: (v) async {
                if (v == null) return;
                await Settings.setThemeMode(v);
                setState(() {});
              },
            ),
          ),
        ),
        const SizedBox(height: 16),
        _section('الأمان'),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.pin),
                title: const Text('رمز PIN'),
                subtitle: Text(Settings.hasPin
                    ? 'مفعّل'
                    : 'لحماية التطبيق عند الفتح'),
                trailing: Switch(
                  value: Settings.hasPin,
                  onChanged: (v) async {
                    if (v) {
                      final pin = await _askPin(context);
                      if (pin != null && pin.length >= 4) {
                        await Settings.setPin(pin);
                        setState(() {});
                      }
                    } else {
                      await Settings.removePin();
                      setState(() {});
                    }
                  },
                ),
              ),
              if (Settings.hasPin)
                ListTile(
                  leading: const Icon(Icons.fingerprint),
                  title: const Text('فتح بالبصمة'),
                  trailing: Switch(
                    value: Settings.biometricEnabled,
                    onChanged: (v) async {
                      if (v) {
                        try {
                          final ok = await LocalAuthentication().authenticate(
                            localizedReason: 'تأكيد تفعيل البصمة',
                            options: const AuthenticationOptions(
                                biometricOnly: true),
                          );
                          if (!ok) return;
                        } catch (_) {
                          return;
                        }
                      }
                      await Settings.setBiometricEnabled(v);
                      setState(() {});
                    },
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _section('العملة والتنبيهات'),
        Card(
          child: ListTile(
            leading: const Icon(Icons.attach_money),
            title: const Text('العملة الافتراضية'),
            subtitle: Text(Settings.defaultCurrency),
            trailing: const Icon(Icons.chevron_left),
            onTap: () async {
              final ctrl = TextEditingController(text: Settings.defaultCurrency);
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('العملة'),
                  content: TextField(
                    controller: ctrl,
                    decoration:
                        const InputDecoration(border: OutlineInputBorder()),
                  ),
                  actions: [
                    TextButton(
                        onPressed: () => Navigator.pop(ctx, false),
                        child: const Text('إلغاء')),
                    FilledButton(
                        onPressed: () => Navigator.pop(ctx, true),
                        child: const Text('حفظ')),
                  ],
                ),
              );
              if (ok == true && ctrl.text.trim().isNotEmpty) {
                await Settings.setDefaultCurrency(ctrl.text.trim());
                setState(() {});
              }
            },
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.notifications_active),
            title: const Text('إعادة جدولة التذكيرات'),
            subtitle: const Text('تحديث تذكيرات الاستحقاق'),
            onTap: () async {
              await NotificationsHelper.rescheduleAll();
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تمت إعادة الجدولة')),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        _section('النسخ الاحتياطي والتقارير'),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.upload_file),
                title: const Text('تصدير نسخة احتياطية (JSON)'),
                onTap: () => BackupHelper.exportBackup(),
              ),
              ListTile(
                leading: const Icon(Icons.download),
                title: const Text('استرجاع نسخة احتياطية'),
                subtitle: const Text('سيتم استبدال كل البيانات الحالية'),
                onTap: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('استرجاع'),
                      content: const Text(
                          'سيتم استبدال كل البيانات الحالية. متابعة؟'),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(ctx, false),
                            child: const Text('إلغاء')),
                        FilledButton(
                            onPressed: () => Navigator.pop(ctx, true),
                            child: const Text('متابعة')),
                      ],
                    ),
                  );
                  if (ok != true) return;
                  try {
                    final done = await BackupHelper.importBackup();
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content:
                            Text(done ? 'تم الاسترجاع' : 'لم يتم الاسترجاع')));
                  } catch (e) {
                    if (!mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('خطأ: $e')));
                  }
                },
              ),
              ListTile(
                leading: const Icon(Icons.picture_as_pdf),
                title: const Text('تقرير PDF عام'),
                onTap: () => PdfHelper.exportFullReport(),
              ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        _section('حول'),
        const Card(
          child: ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('دفتر الديون — الإصدار 2.0'),
            subtitle: Text('تطبيق محلي بالكامل بدون إنترنت، بيانتك عندك.'),
          ),
        ),
      ],
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
        child: Text(t,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      );

  Future<String?> _askPin(BuildContext context) async {
    final ctrl = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تعيين رمز PIN'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          obscureText: true,
          maxLength: 6,
          decoration: const InputDecoration(
            labelText: 'رمز من 4 إلى 6 أرقام',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text),
              child: const Text('حفظ')),
        ],
      ),
    );
  }
}
