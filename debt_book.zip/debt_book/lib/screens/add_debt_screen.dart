import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/debt.dart';
import '../utils/format.dart';
import '../utils/notifications_helper.dart';
import '../utils/settings.dart';

class AddDebtScreen extends StatefulWidget {
  final int personId;
  final String personName;
  final Debt? existing;
  const AddDebtScreen({
    super.key,
    required this.personId,
    required this.personName,
    this.existing,
  });

  @override
  State<AddDebtScreen> createState() => _AddDebtScreenState();
}

class _AddDebtScreenState extends State<AddDebtScreen> {
  final _amount = TextEditingController();
  final _currency = TextEditingController();
  final _note = TextEditingController();
  final _category = TextEditingController();

  int _type = 0;
  DateTime _date = DateTime.now();
  DateTime? _dueDate;

  static const _categories = [
    'قرض شخصي',
    'إيجار',
    'أقساط',
    'بضاعة',
    'مصاريف',
    'أخرى',
  ];

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _currency.text = e?.currency ?? Settings.defaultCurrency;
    if (e != null) {
      _amount.text = e.amount.toString();
      _type = e.type;
      _note.text = e.note ?? '';
      _category.text = e.category ?? '';
      _date = DateTime.tryParse(e.date) ?? DateTime.now();
      _dueDate = e.dueDate != null ? DateTime.tryParse(e.dueDate!) : null;
    }
  }

  Future<void> _pickDate({required bool due}) async {
    final initial = due ? (_dueDate ?? DateTime.now()) : _date;
    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked == null) return;
    setState(() {
      if (due) {
        _dueDate = picked;
      } else {
        _date = picked;
      }
    });
  }

  Future<void> _save() async {
    final amount = double.tryParse(_amount.text.trim().replaceAll(',', '.'));
    if (amount == null || amount <= 0) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('أدخل مبلغاً صحيحاً')));
      return;
    }

    final debt = Debt(
      id: widget.existing?.id,
      personId: widget.personId,
      type: _type,
      amount: amount,
      currency: _currency.text.trim().isEmpty ? 'ر.س' : _currency.text.trim(),
      date: _date.toIso8601String().substring(0, 10),
      dueDate: _dueDate?.toIso8601String().substring(0, 10),
      note: _note.text.trim().isEmpty ? null : _note.text.trim(),
      category: _category.text.trim().isEmpty ? null : _category.text.trim(),
    );

    int id;
    if (debt.id == null) {
      id = await DatabaseHelper.instance.insertDebt(debt);
    } else {
      await DatabaseHelper.instance.updateDebt(debt);
      id = debt.id!;
    }

    if (_dueDate != null) {
      await NotificationsHelper.scheduleDebtReminder(
        debtId: id,
        personName: widget.personName,
        amount: amount,
        currency: debt.currency,
        dueDate: _dueDate!,
      );
    } else {
      await NotificationsHelper.cancel(id);
    }

    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final color = _type == 0 ? Colors.green : Colors.red;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.existing == null ? 'دين جديد' : 'تعديل الدين'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(
                  value: 0,
                  label: Text('لي (أقرضت)'),
                  icon: Icon(Icons.call_made)),
              ButtonSegment(
                  value: 1,
                  label: Text('عليّ (استدنت)'),
                  icon: Icon(Icons.call_received)),
            ],
            selected: {_type},
            onSelectionChanged: (s) => setState(() => _type = s.first),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _amount,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: InputDecoration(
              labelText: 'المبلغ',
              border: const OutlineInputBorder(),
              prefixIcon: Icon(Icons.payments, color: color),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _currency,
            decoration: const InputDecoration(
              labelText: 'العملة',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.attach_money),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _category.text.isEmpty ? null : _category.text,
            decoration: const InputDecoration(
              labelText: 'التصنيف',
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.category),
            ),
            items: _categories
                .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                .toList(),
            onChanged: (v) => _category.text = v ?? '',
          ),
          const SizedBox(height: 12),
          ListTile(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: const BorderSide(color: Colors.grey),
            ),
            leading: const Icon(Icons.event),
            title: const Text('تاريخ الدين'),
            subtitle: Text(dateStr(_date.toIso8601String())),
            trailing: TextButton(
              onPressed: () => _pickDate(due: false),
              child: const Text('تغيير'),
            ),
          ),
          const SizedBox(height: 12),
          ListTile(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
              side: const BorderSide(color: Colors.grey),
            ),
            leading: const Icon(Icons.alarm),
            title: const Text('تاريخ الاستحقاق (اختياري)'),
            subtitle: Text(_dueDate == null
                ? 'غير محدد'
                : dateStr(_dueDate!.toIso8601String())),
            trailing: _dueDate == null
                ? TextButton(
                    onPressed: () => _pickDate(due: true),
                    child: const Text('تحديد'),
                  )
                : IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => setState(() => _dueDate = null),
                  ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _note,
            maxLines: 3,
            decoration: const InputDecoration(
              labelText: 'ملاحظة (اختياري)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            style: FilledButton.styleFrom(
                backgroundColor: color, padding: const EdgeInsets.all(14)),
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('حفظ الدين'),
          ),
        ],
      ),
    );
  }
}
