import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/debt.dart';
import '../models/person.dart';
import '../utils/format.dart';
import '../utils/pdf_helper.dart';
import 'add_debt_screen.dart';
import 'debt_details_screen.dart';

class PersonScreen extends StatefulWidget {
  final Person person;
  const PersonScreen({super.key, required this.person});

  @override
  State<PersonScreen> createState() => _PersonScreenState();
}

class _PersonScreenState extends State<PersonScreen> {
  late Future<List<DebtView>> _future;

  @override
  void initState() {
    super.initState();
    _future = DatabaseHelper.instance.getDebtsForPerson(widget.person.id!);
  }

  void _load() {
    setState(() =>
        _future = DatabaseHelper.instance.getDebtsForPerson(widget.person.id!));
  }

  Future<void> _addDebt() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AddDebtScreen(
          personId: widget.person.id!,
          personName: widget.person.name,
        ),
      ),
    );
    _load();
  }

  Future<void> _openDebt(DebtView v) async {
    await Navigator.push(context,
        MaterialPageRoute(builder: (_) => DebtDetailsScreen(debt: v.debt)));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.person.name),
        actions: [
          IconButton(
            tooltip: 'كشف حساب PDF',
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () => PdfHelper.exportPersonStatement(widget.person),
          ),
        ],
      ),
      body: FutureBuilder<List<DebtView>>(
        future: _future,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data ?? [];
          double lent = 0, borrowed = 0;
          for (final v in list) {
            if (v.debt.type == 0) {
              lent += v.remaining;
            } else {
              borrowed += v.remaining;
            }
          }
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            children: [
              _summary(lent, borrowed),
              const SizedBox(height: 16),
              const Text('الديون',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (list.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(
                    child: Text('لا توجد ديون مسجلة',
                        style: TextStyle(color: Colors.grey)),
                  ),
                ),
              ...list.map(_debtCard),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addDebt,
        icon: const Icon(Icons.add),
        label: const Text('دين جديد'),
      ),
    );
  }

  Widget _summary(double lent, double borrowed) {
    return Row(
      children: [
        Expanded(child: _box('لي', lent, Colors.green)),
        const SizedBox(width: 12),
        Expanded(child: _box('عليّ', borrowed, Colors.red)),
      ],
    );
  }

  Widget _box(String t, double v, Color c) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: c.withOpacity(0.1),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: c.withOpacity(0.4)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(t, style: TextStyle(color: c, fontWeight: FontWeight.w600)),
            const SizedBox(height: 4),
            Text(money(v),
                style: TextStyle(
                    color: c, fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
      );

  Widget _debtCard(DebtView v) {
    final d = v.debt;
    final isLent = d.type == 0;
    final color = isLent ? Colors.green : Colors.red;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _openDebt(v),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(isLent ? 'لي' : 'عليّ',
                        style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                            fontSize: 12)),
                  ),
                  if (v.isSettled) ...[
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Text('مسدد',
                          style: TextStyle(fontSize: 11, color: Colors.grey)),
                    ),
                  ],
                  if (d.category != null && d.category!.isNotEmpty) ...[
                    const SizedBox(width: 6),
                    Text(d.category!,
                        style: const TextStyle(
                            fontSize: 11, color: Colors.blueGrey)),
                  ],
                  const Spacer(),
                  Text('${money(d.amount)} ${d.currency}',
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 8),
              Text('المتبقي: ${money(v.remaining)} ${d.currency}',
                  style:
                      TextStyle(color: color, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              LinearProgressIndicator(
                value: v.progress,
                color: color,
                backgroundColor: color.withOpacity(0.15),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Text(dateStr(d.date),
                      style: const TextStyle(
                          fontSize: 12, color: Colors.grey)),
                  if (d.dueDate != null && d.dueDate!.isNotEmpty) ...[
                    const SizedBox(width: 12),
                    Text('الاستحقاق: ${dateStr(d.dueDate!)}',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.grey)),
                  ],
                ],
              ),
              if (d.note != null && d.note!.isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(d.note!, style: const TextStyle(fontSize: 12)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
