import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';

import '../utils/settings.dart';
import 'home_screen.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final _pinCtrl = TextEditingController();
  String? _error;

  @override
  void initState() {
    super.initState();
    if (Settings.biometricEnabled) _tryBiometric();
  }

  Future<void> _tryBiometric() async {
    try {
      final auth = LocalAuthentication();
      final ok = await auth.authenticate(
        localizedReason: 'فتح دفتر الديون',
        options: const AuthenticationOptions(biometricOnly: true),
      );
      if (ok && mounted) _goHome();
    } catch (_) {}
  }

  void _goHome() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const HomeScreen()),
    );
  }

  void _checkPin() {
    if (_pinCtrl.text == Settings.pin) {
      _goHome();
    } else {
      setState(() => _error = 'رمز خاطئ');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.lock, size: 64, color: Colors.green),
              const SizedBox(height: 16),
              const Text('أدخل رمز PIN',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              TextField(
                controller: _pinCtrl,
                obscureText: true,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 6,
                decoration: InputDecoration(
                  border: const OutlineInputBorder(),
                  errorText: _error,
                  labelText: 'الرمز',
                ),
                onSubmitted: (_) => _checkPin(),
              ),
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: _checkPin,
                  child: const Text('دخول'),
                ),
              ),
              if (Settings.biometricEnabled)
                TextButton.icon(
                  onPressed: _tryBiometric,
                  icon: const Icon(Icons.fingerprint),
                  label: const Text('استخدام البصمة'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
