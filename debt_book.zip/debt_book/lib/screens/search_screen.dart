import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/person_summary.dart';
import '../utils/format.dart';
import 'person_screen.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctrl = TextEditingController();
  late Future<List<PersonSummary>> _future;
  List<Map<String, dynamic>> _debts = [];

  @override
  void initState() {
    super.initState();
    _future = DatabaseHelper.instance.getPersonSummaries();
  }

  Future<void> _search(String q) async {
    setState(() {
      _future = DatabaseHelper.instance.getPersonSummaries(search: q);
    });
    final debts = q.trim().isEmpty
        ? <Map<String, dynamic>>[]
        : await DatabaseHelper.instance.searchDebts(q.trim());
    if (mounted) setState(() => _debts = debts);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: _ctrl,
          autofocus: true,
          decoration: const InputDecoration(
            hintText: 'ابحث بالاسم أو الملاحظة أو التصنيف…',
            border: InputBorder.none,
          ),
          onChanged: _search,
        ),
      ),
      body: FutureBuilder<List<PersonSummary>>(
        future: _future,
        builder: (context, snap) {
          final persons = snap.data ?? [];
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              if (persons.isNotEmpty) ...[
                const Text('الأشخاص',
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                ...persons.map(
                  (s) => Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text(s.person.name.isNotEmpty
                            ? s.person.name[0]
                            : '?'),
                      ),
                      title: Text(s.person.name),
                      subtitle: Text(
                        s.net == 0
                            ? 'مسدد'
                            : (s.net > 0
                                ? 'لي ${money(s.net)}'
                                : 'عليّ ${money(s.net.abs())}'),
                      ),
                      onTap: () async {
                        await Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) =>
                                    PersonScreen(person: s.person)));
                        _search(_ctrl.text);
                      },
                    ),
                  ),
                ),
              ],
              if (_debts.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Text('الديون',
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                ..._debts.map((d) {
                  final type = d['type'] as int;
                  final amount = (d['amount'] as num).toDouble();
                  final paid = (d['paid'] as num).toDouble();
                  final remaining = amount - paid;
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        type == 0 ? Icons.call_made : Icons.call_received,
                        color: type == 0 ? Colors.green : Colors.red,
                      ),
                      title: Text(d['person_name'] as String),
                      subtitle: Text(
                        '${money(remaining)} / ${money(amount)} ${d['currency'] ?? ''} • ${dateStr(d['date'] as String)}',
                      ),
                    ),
                  );
                }),
              ],
            ],
          );
        },
      ),
    );
  }
}
