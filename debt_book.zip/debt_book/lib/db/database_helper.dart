import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/debt.dart';
import '../models/payment.dart';
import '../models/person.dart';
import '../models/person_summary.dart';

class _Acc {
  final Person person;
  double lent = 0;
  double borrowed = 0;
  _Acc(this.person);
}

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._();
  DatabaseHelper._();

  static Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final path = join(await getDatabasesPath(), 'debt_book.db');
    return openDatabase(
      path,
      version: 2,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE persons(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            created_at TEXT
          )
        ''');
        await db.execute('''
          CREATE TABLE debts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            person_id INTEGER NOT NULL,
            type INTEGER NOT NULL,
            amount REAL NOT NULL,
            currency TEXT NOT NULL DEFAULT 'ر.س',
            date TEXT NOT NULL,
            due_date TEXT,
            note TEXT,
            category TEXT,
            FOREIGN KEY(person_id) REFERENCES persons(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE payments(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            debt_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            note TEXT,
            FOREIGN KEY(debt_id) REFERENCES debts(id) ON DELETE CASCADE
          )
        ''');
      },
      onUpgrade: (db, oldV, newV) async {
        if (oldV < 2) {
          await db.execute('ALTER TABLE persons ADD COLUMN created_at TEXT');
          await db.execute('ALTER TABLE debts ADD COLUMN category TEXT');
        }
      },
    );
  }

  // ---------- Persons ----------

  Future<int> insertPerson(Person p) async {
    final db = await database;
    return db.insert('persons', p.toMap());
  }

  Future<int> updatePerson(Person p) async {
    final db = await database;
    return db.update('persons', p.toMap(), where: 'id = ?', whereArgs: [p.id]);
  }

  Future<int> deletePerson(int id) async {
    final db = await database;
    return db.delete('persons', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Person>> getAllPersons() async {
    final db = await database;
    final rows = await db.query('persons', orderBy: 'name');
    return rows.map(Person.fromMap).toList();
  }

  // ---------- Summaries ----------

  Future<List<PersonSummary>> getPersonSummaries({String? search}) async {
    final db = await database;
    final where = (search != null && search.trim().isNotEmpty)
        ? 'WHERE p.name LIKE ?'
        : '';
    final args = (search != null && search.trim().isNotEmpty)
        ? ['%${search.trim()}%']
        : [];

    final rows = await db.rawQuery('''
      SELECT p.id AS pid, p.name AS name, p.phone AS phone,
             d.type AS type, d.amount AS amount,
             COALESCE((SELECT SUM(pay.amount) FROM payments pay WHERE pay.debt_id = d.id), 0) AS paid
      FROM persons p
      LEFT JOIN debts d ON d.person_id = p.id
      $where
      ORDER BY p.name
    ''', args);

    final acc = <int, _Acc>{};
    for (final r in rows) {
      final pid = r['pid'] as int;
      acc.putIfAbsent(
        pid,
        () => _Acc(Person(
          id: pid,
          name: r['name'] as String,
          phone: r['phone'] as String?,
        )),
      );
      final type = r['type'];
      if (type != null) {
        final amount = (r['amount'] as num).toDouble();
        final paid = (r['paid'] as num).toDouble();
        final remaining = amount - paid;
        if ((type as int) == 0) {
          acc[pid]!.lent += remaining;
        } else {
          acc[pid]!.borrowed += remaining;
        }
      }
    }
    return acc.values
        .map((a) => PersonSummary(
              person: a.person,
              lentRemaining: a.lent,
              borrowedRemaining: a.borrowed,
            ))
        .toList();
  }

  // ---------- Debts ----------

  Future<int> insertDebt(Debt d) async {
    final db = await database;
    return db.insert('debts', d.toMap());
  }

  Future<int> updateDebt(Debt d) async {
    final db = await database;
    return db.update('debts', d.toMap(), where: 'id = ?', whereArgs: [d.id]);
  }

  Future<int> deleteDebt(int id) async {
    final db = await database;
    return db.delete('debts', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<DebtView>> getDebtsForPerson(int personId) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT d.*, COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.debt_id = d.id), 0) AS paid
      FROM debts d
      WHERE d.person_id = ?
      ORDER BY d.date DESC, d.id DESC
    ''', [personId]);
    return rows
        .map((r) => DebtView(
              debt: Debt.fromMap(r),
              paid: (r['paid'] as num).toDouble(),
            ))
        .toList();
  }

  Future<List<Map<String, dynamic>>> getDebtsWithDueDates() async {
    final db = await database;
    return db.rawQuery('''
      SELECT d.*, p.name AS person_name,
             COALESCE((SELECT SUM(pay.amount) FROM payments pay WHERE pay.debt_id = d.id), 0) AS paid
      FROM debts d
      JOIN persons p ON p.id = d.person_id
      WHERE d.due_date IS NOT NULL AND d.due_date != ''
    ''');
  }

  Future<List<Map<String, dynamic>>> searchDebts(String query) async {
    final db = await database;
    return db.rawQuery('''
      SELECT d.*, p.name AS person_name,
             COALESCE((SELECT SUM(pay.amount) FROM payments pay WHERE pay.debt_id = d.id), 0) AS paid
      FROM debts d
      JOIN persons p ON p.id = d.person_id
      WHERE p.name LIKE ? OR d.note LIKE ? OR d.category LIKE ?
      ORDER BY d.date DESC
    ''', ['%$query%', '%$query%', '%$query%']);
  }

  // ---------- Payments ----------

  Future<int> insertPayment(Payment p) async {
    final db = await database;
    return db.insert('payments', p.toMap());
  }

  Future<int> deletePayment(int id) async {
    final db = await database;
    return db.delete('payments', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Payment>> getPayments(int debtId) async {
    final db = await database;
    final rows = await db.query(
      'payments',
      where: 'debt_id = ?',
      whereArgs: [debtId],
      orderBy: 'date DESC, id DESC',
    );
    return rows.map(Payment.fromMap).toList();
  }

  // ---------- Statistics ----------

  Future<Map<String, dynamic>> getStatistics() async {
    final db = await database;
    final totals = await db.rawQuery('''
      SELECT d.type,
             SUM(d.amount) AS total,
             COALESCE((SELECT SUM(p.amount) FROM payments p
                       JOIN debts dd ON dd.id = p.debt_id
                       WHERE dd.type = d.type), 0) AS paid
      FROM debts d GROUP BY d.type
    ''');

    double lent = 0, borrowed = 0, paidLent = 0, paidBorrowed = 0;
    for (final r in totals) {
      final type = r['type'] as int;
      final total = (r['total'] as num).toDouble();
      final paid = (r['paid'] as num).toDouble();
      if (type == 0) {
        lent += total;
        paidLent += paid;
      } else {
        borrowed += total;
        paidBorrowed += paid;
      }
    }

    final monthly = await db.rawQuery('''
      SELECT substr(date, 1, 7) AS m, type, SUM(amount) AS total
      FROM debts
      GROUP BY m, type
      ORDER BY m DESC
      LIMIT 12
    ''');

    final categories = await db.rawQuery('''
      SELECT COALESCE(category, 'غير مصنف') AS cat, SUM(amount) AS total
      FROM debts
      GROUP BY cat
      ORDER BY total DESC
      LIMIT 6
    ''');

    return {
      'lentRemaining': lent - paidLent,
      'borrowedRemaining': borrowed - paidBorrowed,
      'paidLent': paidLent,
      'paidBorrowed': paidBorrowed,
      'monthly': monthly,
      'categories': categories,
    };
  }

  // ---------- Backup ----------

  Future<Map<String, dynamic>> exportAll() async {
    final db = await database;
    return {
      'version': 2,
      'exported_at': DateTime.now().toIso8601String(),
      'persons': await db.query('persons'),
      'debts': await db.query('debts'),
      'payments': await db.query('payments'),
    };
  }

  Future<void> importAll(Map<String, dynamic> data) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('payments');
      await txn.delete('debts');
      await txn.delete('persons');

      for (final p in (data['persons'] as List? ?? [])) {
        await txn.insert('persons', Map<String, dynamic>.from(p));
      }
      for (final d in (data['debts'] as List? ?? [])) {
        await txn.insert('debts', Map<String, dynamic>.from(d));
      }
      for (final p in (data['payments'] as List? ?? [])) {
        await txn.insert('payments', Map<String, dynamic>.from(p));
      }
    });
  }
}
