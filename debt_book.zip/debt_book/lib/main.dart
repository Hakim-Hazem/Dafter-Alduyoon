import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'screens/splash_screen.dart';
import 'utils/notifications_helper.dart';
import 'utils/settings.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Settings.init();
  try {
    await NotificationsHelper.init();
  } catch (_) {
    // لا نوقف تشغيل التطبيق إذا فشلت تهيئة الإشعارات
  }
  runApp(const DebtBookApp());
}

class DebtBookApp extends StatefulWidget {
  const DebtBookApp({super.key});

  @override
  State<DebtBookApp> createState() => _DebtBookAppState();
}

class _DebtBookAppState extends State<DebtBookApp> {
  @override
  void initState() {
    super.initState();
    Settings.themeMode.addListener(_rebuild);
  }

  @override
  void dispose() {
    Settings.themeMode.removeListener(_rebuild);
    super.dispose();
  }

  void _rebuild() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'دفتر الديون',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2E7D32),
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF2E7D32),
        brightness: Brightness.dark,
      ),
      themeMode: Settings.themeMode.value,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      builder: (context, child) =>
          Directionality(textDirection: TextDirection.rtl, child: child!),
      home: const SplashScreen(),
    );
  }
}
