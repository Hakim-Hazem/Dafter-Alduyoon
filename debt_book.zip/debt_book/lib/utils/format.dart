import 'package:intl/intl.dart';

final NumberFormat _money = NumberFormat('#,##0.00', 'en');
final DateFormat _date = DateFormat('yyyy/MM/dd');

String money(double v) => _money.format(v);

String dateStr(String iso) {
  try {
    return _date.format(DateTime.parse(iso));
  } catch (_) {
    return iso;
  }
}

String todayIso() => DateTime.now().toIso8601String().substring(0, 10);

String monthKey(String iso) {
  try {
    final d = DateTime.parse(iso);
    return '${d.year}-${d.month.toString().padLeft(2, '0')}';
  } catch (_) {
    return iso;
  }
}

String monthLabel(String key) {
  try {
    final parts = key.split('-');
    final y = int.parse(parts[0]);
    final m = int.parse(parts[1]);
    return DateFormat('MMM yyyy').format(DateTime(y, m));
  } catch (_) {
    return key;
  }
}
