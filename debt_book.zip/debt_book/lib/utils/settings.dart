import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Settings {
  static late SharedPreferences _prefs;

  static final ValueNotifier<ThemeMode> themeMode =
      ValueNotifier(ThemeMode.system);

  static String defaultCurrency = 'ر.س';
  static bool biometricEnabled = false;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    final mode = _prefs.getString('theme_mode') ?? 'system';
    themeMode.value = _parseMode(mode);
    defaultCurrency = _prefs.getString('default_currency') ?? 'ر.س';
    biometricEnabled = _prefs.getBool('biometric') ?? false;
  }

  static ThemeMode _parseMode(String s) {
    switch (s) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  static Future<void> setThemeMode(ThemeMode m) async {
    themeMode.value = m;
    await _prefs.setString('theme_mode', m.name);
  }

  static Future<void> setDefaultCurrency(String c) async {
    defaultCurrency = c;
    await _prefs.setString('default_currency', c);
  }

  static Future<void> setBiometricEnabled(bool v) async {
    biometricEnabled = v;
    await _prefs.setBool('biometric', v);
  }

  // PIN
  static String? get pin => _prefs.getString('pin');
  static bool get hasPin => (pin ?? '').isNotEmpty;
  static Future<void> setPin(String v) async => _prefs.setString('pin', v);
  static Future<void> removePin() async => _prefs.remove('pin');

  // Hidden amounts
  static bool get hideAmounts => _prefs.getBool('hide_amounts') ?? false;
  static Future<void> setHideAmounts(bool v) async =>
      _prefs.setBool('hide_amounts', v);
}
