import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../db/database_helper.dart';

class NotificationsHelper {
  static final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    tz.initializeTimeZones();

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings(
      requestAlertPermission: false,
      requestBadgePermission: false,
      requestSoundPermission: false,
    );

    await _plugin.initialize(
      const InitializationSettings(android: android, iOS: ios),
    );

    // Android 13+ permission
    await _plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.requestNotificationsPermission();
  }

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'debt_reminders',
      'تذكيرات الديون',
      channelDescription: 'تنبيهات مواعيد استحقاق الديون',
      importance: Importance.high,
      priority: Priority.high,
    ),
    iOS: DarwinNotificationDetails(),
  );

  static Future<void> scheduleDebtReminder({
    required int debtId,
    required String personName,
    required double amount,
    required String currency,
    required DateTime dueDate,
  }) async {
    // جدولة التنبيه في تمام الساعة 9 صباحاً بيوم الاستحقاق
    // نحسب الساعة 9 صباحاً بتوقيت الجهاز ثم نحوّلها للحظة زمنية مطلقة
    final when = tz.TZDateTime.from(
      DateTime(dueDate.year, dueDate.month, dueDate.day, 9),
      tz.local,
    );
    if (when.isBefore(tz.TZDateTime.now(tz.local))) return;

    try {
      await _plugin.zonedSchedule(
        debtId,
        'تذكير دين',
        'دين على/لـ $personName بمبلغ ${amount.toStringAsFixed(2)} $currency مستحق اليوم',
        when,
        _details,
        // inexact لا يحتاج إذن "المنبهات الدقيقة" في Android 12+
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (_) {}
  }

  static Future<void> cancel(int debtId) =>
      _plugin.cancel(debtId);

  static Future<void> rescheduleAll() async {
    await _plugin.cancelAll();
    final debts = await DatabaseHelper.instance.getDebtsWithDueDates();
    for (final d in debts) {
      final amount = (d['amount'] as num).toDouble();
      final paid = (d['paid'] as num).toDouble();
      if (amount - paid <= 0.0001) continue;
      try {
        final due = DateTime.parse(d['due_date'] as String);
        await scheduleDebtReminder(
          debtId: d['id'] as int,
          personName: d['person_name'] as String,
          amount: amount - paid,
          currency: (d['currency'] as String?) ?? 'ر.س',
          dueDate: due,
        );
      } catch (_) {}
    }
  }
}
