import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../db/database_helper.dart';
import '../models/debt.dart';
import '../models/payment.dart';
import '../models/person.dart';
import 'format.dart';

class PdfHelper {
  static Future<void> _print(pw.Document doc, String filename) async {
    await Printing.layoutPdf(
      name: filename,
      onLayout: (_) async => doc.save(),
    );
  }

  // الخط مضمّن داخل التطبيق (يعمل بدون إنترنت)، وإن لم يوجد يُحمّل من Google Fonts
  static Future<pw.Font> _loadFont(
      String asset, Future<pw.Font> Function() fallback) async {
    try {
      final data = await rootBundle.load(asset);
      return pw.Font.ttf(data);
    } catch (_) {
      return fallback();
    }
  }

  static Future<pw.Font> _arRegular() => _loadFont(
      'assets/fonts/Amiri-Regular.ttf', PdfGoogleFonts.amiriRegular);
  static Future<pw.Font> _arBold() =>
      _loadFont('assets/fonts/Amiri-Bold.ttf', PdfGoogleFonts.amiriBold);

  static pw.Widget _h(String t, pw.Font font, {double size = 18}) =>
      pw.Text(t, style: pw.TextStyle(font: font, fontSize: size));

  static pw.Widget _cell(String t, pw.Font font, {double size = 11}) =>
      pw.Text(t, style: pw.TextStyle(font: font, fontSize: size));

  /// كشف حساب لشخص معين
  static Future<void> exportPersonStatement(Person person) async {
    final regular = await _arRegular();
    final bold = await _arBold();
    final debts = await DatabaseHelper.instance.getDebtsForPerson(person.id!);

    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      textDirection: pw.TextDirection.rtl,
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Center(child: _h('كشف حساب', bold, size: 22)),
        pw.SizedBox(height: 8),
        pw.Center(child: _h(person.name, regular, size: 16)),
        if (person.phone != null && person.phone!.isNotEmpty)
          pw.Center(child: _cell(person.phone!, regular)),
        pw.SizedBox(height: 6),
        pw.Center(child: _cell('تاريخ الطباعة: ${dateStr(todayIso())}', regular)),
        pw.SizedBox(height: 20),
        pw.TableHelper.fromTextArray(
          headers: ['النوع', 'المبلغ', 'المسدد', 'المتبقي', 'التاريخ', 'الاستحقاق', 'ملاحظة'],
          data: debts
              .map((v) => [
                    v.debt.type == 0 ? 'لي' : 'عليّ',
                    '${money(v.debt.amount)} ${v.debt.currency}',
                    money(v.paid),
                    money(v.remaining),
                    dateStr(v.debt.date),
                    v.debt.dueDate == null ? '-' : dateStr(v.debt.dueDate!),
                    v.debt.note ?? '-',
                  ])
              .toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 11, color: PdfColors.white),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.green700),
          cellStyle: pw.TextStyle(font: regular, fontSize: 10),
          cellAlignments: {
            0: pw.Alignment.center,
            1: pw.Alignment.center,
            2: pw.Alignment.center,
            3: pw.Alignment.center,
            4: pw.Alignment.center,
            5: pw.Alignment.center,
            6: pw.Alignment.center,
          },
        ),
      ],
    ));
    await _print(doc, 'كشف_${person.name}');
  }

  /// تقرير عام
  static Future<void> exportFullReport() async {
    final regular = await _arRegular();
    final bold = await _arBold();
    final summaries = await DatabaseHelper.instance.getPersonSummaries();

    double lent = 0, borrowed = 0;
    for (final s in summaries) {
      lent += s.lentRemaining;
      borrowed += s.borrowedRemaining;
    }

    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      textDirection: pw.TextDirection.rtl,
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Center(child: _h('تقرير عام - دفتر الديون', bold, size: 22)),
        pw.SizedBox(height: 8),
        pw.Center(child: _cell('تاريخ التقرير: ${dateStr(todayIso())}', regular)),
        pw.SizedBox(height: 16),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            _cell('إجمالي لي: ${money(lent)}', regular, size: 13),
            _cell('إجمالي عليّ: ${money(borrowed)}', regular, size: 13),
            _cell('الصافي: ${money(lent - borrowed)}', regular, size: 13),
          ],
        ),
        pw.SizedBox(height: 20),
        pw.TableHelper.fromTextArray(
          headers: ['الاسم', 'لي', 'عليّ', 'الصافي'],
          data: summaries
              .map((s) => [
                    s.person.name,
                    money(s.lentRemaining),
                    money(s.borrowedRemaining),
                    money(s.net),
                  ])
              .toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 12, color: PdfColors.white),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.green700),
          cellStyle: pw.TextStyle(font: regular, fontSize: 11),
          cellAlignments: {
            0: pw.Alignment.centerRight,
            1: pw.Alignment.center,
            2: pw.Alignment.center,
            3: pw.Alignment.center,
          },
        ),
      ],
    ));
    await _print(doc, 'تقرير_عام');
  }

  /// إيصال دفعة لدين معين
  static Future<void> exportDebtReceipt(Debt debt, List<Payment> payments, String personName) async {
    final regular = await _arRegular();
    final bold = await _arBold();

    double paid = 0;
    for (final p in payments) {
      paid += p.amount;
    }

    final doc = pw.Document();
    doc.addPage(pw.MultiPage(
      textDirection: pw.TextDirection.rtl,
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.all(32),
      build: (ctx) => [
        pw.Center(child: _h('إيصال دين', bold, size: 22)),
        pw.SizedBox(height: 16),
        _cell('الشخص: $personName', regular, size: 13),
        _cell('النوع: ${debt.type == 0 ? "لي (أقرضت)" : "عليّ (استدنت)"}', regular, size: 13),
        _cell('المبلغ الكلي: ${money(debt.amount)} ${debt.currency}', regular, size: 13),
        _cell('المسدد: ${money(paid)} ${debt.currency}', regular, size: 13),
        _cell('المتبقي: ${money(debt.amount - paid)} ${debt.currency}', regular, size: 13),
        _cell('تاريخ الدين: ${dateStr(debt.date)}', regular, size: 13),
        if (debt.dueDate != null && debt.dueDate!.isNotEmpty)
          _cell('الاستحقاق: ${dateStr(debt.dueDate!)}', regular, size: 13),
        if (debt.note != null && debt.note!.isNotEmpty)
          _cell('ملاحظة: ${debt.note!}', regular, size: 13),
        pw.SizedBox(height: 20),
        _h('سجل الدفعات', bold, size: 15),
        pw.SizedBox(height: 8),
        pw.TableHelper.fromTextArray(
          headers: ['التاريخ', 'المبلغ', 'ملاحظة'],
          data: payments
              .map((p) => [dateStr(p.date), money(p.amount), p.note ?? '-'])
              .toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 11, color: PdfColors.white),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.green700),
          cellStyle: pw.TextStyle(font: regular, fontSize: 10),
        ),
      ],
    ));
    await _print(doc, 'إيصال_${personName}');
  }
}
