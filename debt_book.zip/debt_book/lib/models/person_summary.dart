import 'person.dart';

class PersonSummary {
  final Person person;
  final double lentRemaining;
  final double borrowedRemaining;

  PersonSummary({
    required this.person,
    required this.lentRemaining,
    required this.borrowedRemaining,
  });

  double get net => lentRemaining - borrowedRemaining;
}
