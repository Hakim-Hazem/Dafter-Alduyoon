class Debt {
  final int? id;
  final int personId;
  final int type; // 0 = لي، 1 = عليّ
  final double amount;
  final String currency;
  final String date;
  final String? dueDate;
  final String? note;
  final String? category;

  Debt({
    this.id,
    required this.personId,
    required this.type,
    required this.amount,
    required this.currency,
    required this.date,
    this.dueDate,
    this.note,
    this.category,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'person_id': personId,
        'type': type,
        'amount': amount,
        'currency': currency,
        'date': date,
        'due_date': dueDate,
        'note': note,
        'category': category,
      };

  factory Debt.fromMap(Map<String, dynamic> m) => Debt(
        id: m['id'] as int?,
        personId: m['person_id'] as int,
        type: m['type'] as int,
        amount: (m['amount'] as num).toDouble(),
        currency: (m['currency'] as String?) ?? 'ر.س',
        date: m['date'] as String,
        dueDate: m['due_date'] as String?,
        note: m['note'] as String?,
        category: m['category'] as String?,
      );
}

class DebtView {
  final Debt debt;
  final double paid;
  DebtView({required this.debt, required this.paid});

  double get remaining => debt.amount - paid;
  bool get isSettled => remaining <= 0.0001;
  double get progress =>
      debt.amount == 0 ? 0.0 : (paid / debt.amount).clamp(0.0, 1.0);
}
