class Person {
  final int? id;
  final String name;
  final String? phone;
  final String? createdAt;

  Person({this.id, required this.name, this.phone, this.createdAt});

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'phone': phone,
        'created_at': createdAt ?? DateTime.now().toIso8601String(),
      };

  factory Person.fromMap(Map<String, dynamic> m) => Person(
        id: m['id'] as int?,
        name: m['name'] as String,
        phone: m['phone'] as String?,
        createdAt: m['created_at'] as String?,
      );
}
