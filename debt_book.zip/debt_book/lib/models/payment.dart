class Payment {
  final int? id;
  final int debtId;
  final double amount;
  final String date;
  final String? note;

  Payment({
    this.id,
    required this.debtId,
    required this.amount,
    required this.date,
    this.note,
  });

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'debt_id': debtId,
        'amount': amount,
        'date': date,
        'note': note,
      };

  factory Payment.fromMap(Map<String, dynamic> m) => Payment(
        id: m['id'] as int?,
        debtId: m['debt_id'] as int,
        amount: (m['amount'] as num).toDouble(),
        date: m['date'] as String,
        note: m['note'] as String?,
      );
}
