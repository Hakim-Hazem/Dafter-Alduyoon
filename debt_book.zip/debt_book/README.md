# دفتر الديون — مشروع Flutter جاهز لبناء APK

## الطريقة الأولى: بناء APK مجاناً عبر GitHub (بدون تثبيت أي شيء، تعمل من الهاتف أيضاً)

1. أنشئ حساباً على github.com إن لم يكن لديك، ثم أنشئ مستودعاً جديداً (New repository) باسم `debt_book`.
2. اضغط **Add file → Upload files** وارفع **محتويات** هذا المجلد (المجلدات `lib` و `android` و `assets` والملف `pubspec.yaml`... إلخ)، ثم **Commit changes**.
3. ⚠️ المجلد `.github` مخفي وقد لا يُرفع بالسحب والإفلات. للتأكد، اضغط **Add file → Create new file**،
   واكتب في اسم الملف: `.github/workflows/build-apk.yml`
   ثم الصق محتوى الملف `.github/workflows/build-apk.yml` الموجود في هذا المشروع، واضغط **Commit**.
4. افتح تبويب **Actions** في المستودع، ستجد عملية **Build APK** تعمل (تستغرق قرابة 5–10 دقائق).
   إن لم تبدأ تلقائياً: اختر Build APK ← **Run workflow**.
5. عند ظهور ✅ ادخل على العملية، وفي أسفل الصفحة تحت **Artifacts** نزّل `debt-book-apk`،
   فك الضغط ستجد `app-release.apk` — انقله للهاتف وثبّته (اسمح بالتثبيت من مصادر غير معروفة).

## الطريقة الثانية: على جهاز كمبيوتر مثبت عليه Flutter

```bash
flutter create --platforms=android --org com.debtbook --project-name debt_book .
# (اختياري) ضع Amiri-Regular.ttf و Amiri-Bold.ttf داخل assets/fonts لعمل PDF بدون إنترنت
flutter pub get
flutter build apk --release
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

> الأمر `flutter create .` يُكمل الملفات الناقصة فقط ولا يستبدل الملفات الموجودة.
> تم اختبار الإعدادات على Flutter 3.24.5 (استخدم `fvm` أو نفس النسخة لتجنب اختلاف الحزم).

## ملاحظات
- النسخة الناتجة موقّعة بمفتاح تجريبي (debug) — مناسبة للتثبيت المباشر. للنشر على Google Play أنشئ مفتاحاً
  وضع ملف `android/key.properties` يحتوي: `storePassword`, `keyPassword`, `keyAlias`, `storeFile`.
- خط PDF العربي (Amiri) يُضمَّن تلقائياً أثناء البناء عبر GitHub؛ وإن لم يوجد يُحمَّل من الإنترنت عند أول تصدير.
